const express = require("express");
const app = express();

app.use(express.json());

let patients = [];
let caregivers = [];
let games = [];
let sessions = [];
let assessments = [];

let idCounter = 1;

const mysql = require("mysql2");

// Create connection
const db = mysql.createConnection({
    host: "localhost",
    user: "root",          
    password: "root",          
    database: "sosad" 
});

// Connect
db.connect((err) => {
    if (err) {
        console.error("Database connection failed:", err);
        return;
    }
    console.log("Connected to MySQL");
});
/* =========================
   PATIENT RESOURCE
========================= */

// GET all patients
app.get("/patients", (req, res) => {
    res.status(200).json(patients);
});

// GET patient by ID
app.get("/patients/:id", (req, res) => {
    const patient = patients.find(p => p.patient_id == req.params.id);
    if (!patient) return res.status(404).json({ message: "Patient not found" });
    res.status(200).json(patient);
});

// POST create patient
app.post("/patients", (req, res) => {
    const { first_name, last_name, date_of_birth, gender, status } = req.body;

    if (!first_name || !last_name)
        return res.status(400).json({ message: "Missing required fields" });

    const newPatient = {
        patient_id: idCounter++,
        first_name,
        last_name,
        date_of_birth,
        gender,
        status
    };

    patients.push(newPatient);
    res.status(201).json(newPatient);
});

// PUT update patient
app.put("/patients/:id", (req, res) => {
    const patient = patients.find(p => p.patient_id == req.params.id);
    if (!patient) return res.status(404).json({ message: "Patient not found" });

    Object.assign(patient, req.body);
    res.status(200).json(patient);
});

// DELETE patient
app.delete("/patients/:id", (req, res) => {
    patients = patients.filter(p => p.patient_id != req.params.id);
    res.status(200).json({ message: "Patient deleted" });
});


/* =========================
   CAREGIVER RESOURCE
========================= */

app.get("/caregivers", (req, res) => {
    res.status(200).json(caregivers);
});

app.post("/caregivers", (req, res) => {
    const caregiver = { id: idCounter++, ...req.body };
    caregivers.push(caregiver);
    res.status(201).json(caregiver);
});

app.put("/caregivers/:id", (req, res) => {
    const caregiver = caregivers.find(c => c.id == req.params.id);
    if (!caregiver) return res.status(404).json({ message: "Not found" });

    Object.assign(caregiver, req.body);
    res.status(200).json(caregiver);
});

app.delete("/caregivers/:id", (req, res) => {
    caregivers = caregivers.filter(c => c.id != req.params.id);
    res.status(200).json({ message: "Deleted" });
});


/* =========================
   GAME RESOURCE
========================= */

app.get("/games", (req, res) => {
    res.status(200).json(games);
});

app.post("/games", (req, res) => {
    const game = { id: idCounter++, ...req.body };
    games.push(game);
    res.status(201).json(game);
});

app.put("/games/:id", (req, res) => {
    const game = games.find(g => g.id == req.params.id);
    if (!game) return res.status(404).json({ message: "Not found" });

    Object.assign(game, req.body);
    res.status(200).json(game);
});

app.delete("/games/:id", (req, res) => {
    games = games.filter(g => g.id != req.params.id);
    res.status(200).json({ message: "Deleted" });
});


/* =========================
   GAME SESSION RESOURCE
========================= */

app.get("/sessions", (req, res) => {
    res.status(200).json(sessions);
});

app.get("/sessions/:id", (req, res) => {
    const session = sessions.find(s => s.id == req.params.id);
    if (!session) return res.status(404).json({ message: "Not found" });

    res.status(200).json(session);
});

app.post("/sessions", (req, res) => {
    const session = { id: idCounter++, ...req.body };
    sessions.push(session);
    res.status(201).json(session);
});

app.delete("/sessions/:id", (req, res) => {
    sessions = sessions.filter(s => s.id != req.params.id);
    res.status(200).json({ message: "Deleted" });
});


/* =========================
   ASSESSMENT RESOURCE
========================= */

app.get("/assessments", (req, res) => {
    res.status(200).json(assessments);
});

app.post("/assessments", (req, res) => {
    const assessment = { id: idCounter++, ...req.body };
    assessments.push(assessment);
    res.status(201).json(assessment);
});

app.put("/assessments/:id", (req, res) => {
    const assessment = assessments.find(a => a.id == req.params.id);
    if (!assessment) return res.status(404).json({ message: "Not found" });

    Object.assign(assessment, req.body);
    res.status(200).json(assessment);
});

app.delete("/assessments/:id", (req, res) => {
    assessments = assessments.filter(a => a.id != req.params.id);
    res.status(200).json({ message: "Deleted" });
});


/* =========================
   SERVER START
========================= */

app.listen(3000, () => {
    console.log("Server running on http://localhost:3000");
});