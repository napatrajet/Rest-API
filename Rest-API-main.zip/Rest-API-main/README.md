# Brain Training REST API
## Overview

This project implements a RESTful API for managing elderly patients, caregivers, games, sessions, and assessments.

The system follows REST architectural principles and supports full CRUD operations.

## Technologies Used:

    Node.js
    Express.js
    Postman (API testing)
    In-memory data storage

## Features

    CRUD operations for all resources
    JSON request and response format
    Proper HTTP status codes
    Input validation and error handling

## How to Run

    Install dependencies:
```bash
npm install
```
    Start server:
```bash
node server.js
```
    Server runs at:
```bash
http://localhost:3000
```
## API Endpoints

### Patients

    GET /patients
    GET /patients/:id
    POST /patients
    PUT /patients/:id
    DELETE /patients/:id

Similar CRUD structure applies to:

    Caregivers
    Games
    Sessions
    Assessments

## Testing

API tested using Postman to verify:

    CRUD operations
    Error handling (404, 400)
    Proper status codes